setwd("C:\\Users\\dissa\\OneDrive\\Desktop\\It24102410 PS lab 09")

# 1. Meme Counts Example
memes <- c(3, 7, 11, 0, 7, 0, 4, 5, 6, 2)

# H0: mean = 3, H1: mean ≠ 3
t.test(memes, mu = 3, alternative = "two.sided", conf.level = 0.95)


# 2. Weight of Mice
weights <- c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)

# H0: mean = 25, H1: mean < 25
result <- t.test(weights, mu = 25, alternative = "less", conf.level = 0.95)
result

# Extract individual components
result$statistic   # t value
result$p.value     # p-value
result$conf.int    # confidence interval


# 3. Sugar Level of Cookies
set.seed(123)   # for reproducibility
sugar <- rnorm(30, mean = 9.8, sd = 0.05)

# H0: mean = 10, H1: mean > 10
t.test(sugar, mu = 10, alternative = "greater", conf.level = 0.95)


# Exercise Section - Baking Time
set.seed(123)
bake_time <- rnorm(25, mean = 45, sd = 2)

# H0: mean = 46, H1: mean < 46
t.test(bake_time, mu = 46, alternative = "less", conf.level = 0.95)

