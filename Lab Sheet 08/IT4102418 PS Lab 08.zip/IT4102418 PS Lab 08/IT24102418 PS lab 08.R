setwd("C:\\Users\\dissa\\OneDrive\\Desktop\\IT4102418 PS Lab 08")
data<-read.table("Data - Lab 8.txt",header=TRUE)
fix(data)
attach(data)

#Q1
#commands "mean" and "var" will compute the mean and variance for data.
popmn<-mean(Nicotine)
popmn
popvar<-var(Nicotine)
popvar

#Q2
#First create null vector to store sample data set
samples<-c()
n<-c()

#the for loop will be used to create and assign sample of size 5 for "smaple" variable created above.
#using"sample" command we can draw a random sample either with replacement or without replacement.
#by making "replace" argument as TRUE we can create samples with replacement.

for(i in 1:30){
  s<-sample(Nicotine,5,replace=TRUE)
  sample<-cbind(sample,s)
  n<-c(n,paste('s',i))
}  

colnames(samples)=n

#using "apply" command we can ask to calculate any function such as mean,variance.row wise or column wise in amatrix.
s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)

#Q3
#calculate mean and variance
samplemeans<-mean(s.means)
samplevars<-var(s.means)

#Q4
#compare the population mean and mean of sample means.
popmn
samplemean

#Q5
#compare the population variance of sample means.
truecar=popvar/5
samplesvar


#Exercise 2
#Q1
setwd("C:\\Users\\dissa\\OneDrive\\Desktop\\IT4102418 PS Lab 08")
getwd()
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)
attach(data)


weights <- data$Weight.kg.

head(weights)

#Q-01
popmean <- mean(weights)
popsd <- sd(weights)

cat("Population mean =", popmean)
cat("Population standard deviation =", popsd)

#Q-02
numsamples <- 25
samplesize <- 6

#Matrix to store samples
samples <- matrix(nrow = samplesize, ncol = numsamples)
#Generate samples
for (i in 1:numsamples) {
  samples[, i] <- sample(weights, size = samplesize, replace = TRUE)
}
#Name samples
colnames(samples) <- paste("Sample", 1:numsamples, sep = "_")
#Calculate sample means and sample standard deviations
samplemeans <- apply(samples, 2, mean)
samplesds <- apply(samples, 2, sd)

#Display first few sample means and SDs
head(samplemeans)
head(samplesds)

#Q-03
meanofsamplemeans <- mean(samplemeans)
sdofsamplemeans <- sd(samplemeans)

cat("Mean of sample means =", meanofsamplemeans)
cat("Standard deviation of sample means =", sdofsamplemeans)




